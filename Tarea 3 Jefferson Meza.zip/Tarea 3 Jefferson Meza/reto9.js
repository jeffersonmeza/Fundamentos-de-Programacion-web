// Arreglo para almacenar los votos en memoria
let votos = [];

function registrarVoto(event) {
    event.preventDefault();

    const nombre = document.getElementById("nombre").value.trim();
    const cedula = document.getElementById("cedula").value.trim();
    const correo = document.getElementById("correo").value.trim();
    const nacimiento = document.getElementById("nacimiento").value;
    const voto = document.getElementById("voto").value;
    const mensaje = document.getElementById("mensaje");

    // Validación básica
    if (!nombre || !cedula || !correo || !nacimiento || !voto) {
        mensaje.style.color = "red";
        mensaje.innerText = "⚠️ Por favor complete todos los campos.";
        return;
    }

    // Crear el objeto del voto
    const nuevoVoto = {
        nombre,
        cedula,
        correo,
        nacimiento,
        voto
    };

    // Guardar el voto en memoria
    votos.push(nuevoVoto);

    // Limpiar formulario
    document.getElementById("formVoto").reset();

    // Mostrar mensaje de éxito
    mensaje.style.color = "green";
    mensaje.innerText = `✅ ¡Gracias ${nombre}, su voto fue registrado con éxito!`;
}

function mostrarReporte() {
    const tabla = document.getElementById("tablaVotos");
    const cuerpo = tabla.querySelector("tbody");

    // Si no hay votos registrados
    if (votos.length === 0) {
        alert("No hay votos registrados aún.");
        return;
    }

    // Limpiar tabla
    cuerpo.innerHTML = "";

    // Agregar filas a la tabla
    votos.forEach(voto => {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${voto.nombre}</td>
            <td>${voto.cedula}</td>
            <td>${voto.correo}</td>
            <td>${voto.nacimiento}</td>
            <td>${voto.voto}</td>
        `;
        cuerpo.appendChild(fila);
    });

    tabla.style.display = "table";
}
