function cambiarColor() {
    const colores = document.getElementsByName("color");
    const img = document.getElementById("imagenCarro");

    for (let i = 0; i < colores.length; i++) {
        if (colores[i].checked) {
            const color = colores[i].value;
            img.src = "carro_" + color + ".jpeg";
            img.alt = "Carro color " + color;
        }
    }
}

