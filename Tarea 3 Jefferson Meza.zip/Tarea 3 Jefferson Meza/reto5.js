function calcularBebida() {
    const tipo = document.getElementById("tipoBebida").value;
    const tamano = parseInt(document.getElementById("tamano").value);
    const resultadoDiv = document.getElementById("resultado");
    const img = document.getElementById("imagenResultado");

    if (!tipo || isNaN(tamano)) {
        resultadoDiv.innerHTML = "⚠️ Por favor, seleccione tipo y tamaño de bebida.";
        img.style.display = "none";
        return;
    }

    // Ejemplo de cálculo: precio según tamaño
    let precioBase;
    switch(tipo) {
        case "cafe": precioBase = 2; break; // precio base en USD
        case "te": precioBase = 1.5; break;
        case "jugo": precioBase = 2.5; break;
    }

    // Ajuste por tamaño (simple)
    let multiplicador = tamano / 200; // 200ml es la base
    let total = precioBase * multiplicador;

    resultadoDiv.innerHTML = `🍹 Has seleccionado ${tamano} ml de ${tipo}. Total a pagar: $${total.toFixed(2)}`;

    // Mostrar imagen según bebida
    img.src = `/${tipo}.jpeg`;
    img.alt = tipo;
    img.style.display = "block";
}
