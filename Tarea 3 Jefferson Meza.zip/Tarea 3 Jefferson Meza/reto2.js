function generarFactura() {
    const nombre = document.getElementById("nombre").value;
    const articulo = document.getElementById("articulo").value;
    const cantidad = parseFloat(document.getElementById("cantidad").value);
    const precio = parseFloat(document.getElementById("precio").value);
    const resultado = document.getElementById("resultado");

    if (!nombre || !articulo || isNaN(cantidad) || isNaN(precio)) {
        resultado.innerHTML = "⚠️ Por favor, complete todos los campos correctamente.";
        return;
    }

    const subtotal = cantidad * precio;
    const iva = subtotal * 0.13;
    const servicio = subtotal * 0.05;
    const total = subtotal + iva + servicio;

    resultado.innerHTML = `
        <div class="factura-linea"><strong>Cliente:</strong> ${nombre}</div>
        <div class="factura-linea"><strong>Artículo:</strong> ${articulo}</div>
        <div class="factura-linea"><strong>Cantidad:</strong> ${cantidad}</div>
        <div class="factura-linea"><strong>Precio unitario:</strong> ₡${precio.toFixed(2)}</div>
        <hr>
        <div class="factura-linea"><strong>Subtotal:</strong> ₡${subtotal.toFixed(2)}</div>
        <div class="factura-linea"><strong>IVA (13%):</strong> ₡${iva.toFixed(2)}</div>
        <div class="factura-linea"><strong>Servicio (5%):</strong> ₡${servicio.toFixed(2)}</div>
        <hr>
        <div class="factura-linea total"><strong>Total a pagar:</strong> ₡${total.toFixed(2)}</div>
    `;
}
