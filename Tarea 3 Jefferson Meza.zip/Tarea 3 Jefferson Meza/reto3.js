function abrirEnlace() {
    const combo = document.getElementById("selectorEnlace");
    const urlSeleccionada = combo.value;

    if (urlSeleccionada === "") {
        alert("⚠️ Por favor seleccione un sitio antes de continuar.");
    } else {
        // Abre la URL en una nueva pestaña
        window.open(urlSeleccionada, "_blank");
    }
}
