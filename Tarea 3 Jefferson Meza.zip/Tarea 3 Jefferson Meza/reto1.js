function convertir() {
    const monto = parseFloat(document.getElementById('monto').value);
    const tipoCambio = parseFloat(document.getElementById('tipoCambio').value);
    const conversion = document.getElementById('conversion').value;
    const resultadoDiv = document.getElementById('resultado');

    if (isNaN(monto) || isNaN(tipoCambio)) {
        resultadoDiv.innerHTML = "⚠️ Por favor, ingrese valores válidos.";
        return;
    }

    let resultado;

    if (conversion === 'dolares') {
        // De dólares a colones
        resultado = monto * tipoCambio;
        resultadoDiv.innerHTML = `💰 ${monto} dólares son ₡${resultado.toFixed(2)} colones.`;
    } else {
        // De colones a dólares
        resultado = monto / tipoCambio;
        resultadoDiv.innerHTML = `💵 ₡${monto} colones son $${resultado.toFixed(2)} dólares.`;
    }
}