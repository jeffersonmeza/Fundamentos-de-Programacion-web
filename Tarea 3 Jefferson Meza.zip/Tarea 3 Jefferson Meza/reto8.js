// Arreglo en memoria para guardar los registros
let registros = [];

function agregarRegistro() {
    const nombre = document.getElementById("nombre").value.trim();
    const edad = parseInt(document.getElementById("edad").value);
    const select = document.getElementById("consultar");

    if (!nombre || isNaN(edad)) {
        alert("⚠️ Por favor ingrese un nombre y una edad válidos.");
        return;
    }

    // Crear objeto de registro y agregar al arreglo
    const registro = { nombre, edad };
    registros.push(registro);

    // Crear una opción en el combo
    const option = document.createElement("option");
    option.value = registros.length - 1; // índice en el arreglo
    option.text = nombre;
    select.appendChild(option);

    // Limpiar campos
    document.getElementById("nombre").value = "";
    document.getElementById("edad").value = "";

    alert(`Registro de ${nombre} agregado correctamente.`);
}

function mostrarRegistro() {
    const select = document.getElementById("consultar");
    const index = select.value;
    const infoDiv = document.getElementById("info");

    if (index === "") {
        infoDiv.innerHTML = "Aquí se mostrará la información seleccionada.";
        return;
    }

    const registro = registros[index];
    infoDiv.innerHTML = `Nombre: ${registro.nombre} <br> Edad: ${registro.edad}`;
}
