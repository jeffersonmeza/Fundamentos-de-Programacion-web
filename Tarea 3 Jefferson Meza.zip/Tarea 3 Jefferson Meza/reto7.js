function mostrarInfo(planeta) {
const info = document.getElementById("info");

const descripciones = {
    mercurio: "☿ Mercurio es el planeta más cercano al Sol y el más pequeño del sistema solar.",
    venus: "♀ Venus es el planeta más caliente debido a su densa atmósfera de dióxido de carbono.",
    tierra: "🌍 La Tierra es el único planeta conocido con vida y agua líquida en su superficie.",
    marte: "♂ Marte es conocido como el planeta rojo por su superficie rica en óxido de hierro.",
    jupiter: "♃ Júpiter es el planeta más grande, con una gran mancha roja que es una tormenta gigante."
};

info.innerHTML = `
    <select>
    <option>${descripciones[planeta]}</option>
    </select>
`;
}