function mostrarImagen() {
    const combo = document.getElementById("comboImagen");
    const img = document.getElementById("imagenSeleccionada");
    const valor = combo.value;

    if (valor === "") {
        img.style.display = "none";
        img.src = "";
        img.alt = "";
    } else {
        img.src = "" + valor;
        img.alt = combo.options[combo.selectedIndex].text;
        img.style.display = "block";
    }
}
