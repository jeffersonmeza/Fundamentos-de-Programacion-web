document.addEventListener("DOMContentLoaded", () => {
    const empleados = [
        { cedula: "109110338", nombre: "Ana María", apellidos: "Soto Ramírez", lugar: "San José", foto: "https://randomuser.me/api/portraits/women/45.jpg" },
        { cedula: "209110338", nombre: "Luis Alberto", apellidos: "Gómez Vargas", lugar: "Heredia", foto: "https://randomuser.me/api/portraits/men/55.jpg" },
        { cedula: "309110338", nombre: "Karla Fernanda", apellidos: "Jiménez Mora", lugar: "Cartago", foto: "https://randomuser.me/api/portraits/women/32.jpg" },
        { cedula: "409110338", nombre: "David Esteban", apellidos: "Campos López", lugar: "Alajuela", foto: "https://randomuser.me/api/portraits/men/22.jpg" },
        { cedula: "509110338", nombre: "Sofía Isabel", apellidos: "Rojas Quesada", lugar: "Limón", foto: "https://randomuser.me/api/portraits/women/10.jpg" }
    ];

    const btnBuscar = document.getElementById("btnBuscar");
    const inputCedula = document.getElementById("cedula");
    const divResultado = document.getElementById("resultado");

    btnBuscar.addEventListener("click", () => {
        const cedulaIngresada = inputCedula.value.trim();

        if (cedulaIngresada === "") {
            alert("⚠️ Por favor, ingrese una cédula.");
            return;
        }

        const empleado = empleados.find(e => e.cedula === cedulaIngresada);

        if (empleado) {
            divResultado.innerHTML = `
                <h3>✅ Registro encontrado</h3>
                <p><strong>Nombre:</strong> ${empleado.nombre}</p>
                <p><strong>Apellidos:</strong> ${empleado.apellidos}</p>
                <p><strong>Lugar:</strong> ${empleado.lugar}</p>
                <img src="${empleado.foto}" alt="Foto de ${empleado.nombre}">
            `;
        } else {
            divResultado.innerHTML = `
                <select>
                    <option>❌ El usuario NO existe</option>
                </select>
            `;
        }
    });
});
