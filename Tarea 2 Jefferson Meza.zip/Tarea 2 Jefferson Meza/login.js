document.getElementById("btn-login").addEventListener("click", login); 


function validation_alert(ptext) {
    swal.fire({
        title: "Verificar datos",
        text: ptext,
        confirmButtonText: "Intentar de nuevo",
        confirmButtonColor: "#8b0000",
        html: '<iframe width="320" height="240" frameborder="0" src="https://lottie.host/embed/f1899684-940e-44ac-b3ab-4f9402c12b01/vOiiZLe1By.json"></iframe> <br><p>' + ptext + " </p>", 
    });
}

function login() {
    let user_input = document.getElementById("input-user").value;
    let pass_input = document.getElementById("input-password").value;
    let username = "cenfo";
    let password = "123";
    let input = [user_input, pass_input]; 
    let input_id = ["input-user", "input-password"];
    let error_count = 0; 
    let text = "";

    for (let i = 0; i < input.length; i++) {
        document.getElementById(input_id[i]).classList.remove("error"); 
        if (input[i] == "") { 
            text = "Campo Requerido.";
            validation_alert(text);

            document.getElementById(input_id[i]).classList.add("error"); 

            error_count++;
        }
    }

        if (user_input == username && pass_input == password) {
            Swal.fire({
                title: "Usuario verificado",
                showConfirmButton: false,
                customClass: {                 
                    title: 'formatos1',                      
                },
                timer: 5000,
                html: '<iframe width="320" height="240" frameborder="0" src="https://lottie.host/embed/79374a98-a703-48a7-bd60-056d7c41188e/004tuvtarY.json"></iframe> <br><br><p>Esperar un momento...</p>',                
            }).then(() => {
                window.location.href = "landing.html", "blank"; 
            });

        } else {
            text = "Usuario o contraseña incorrecta."; 
            validation_alert(text);
        }
    }

function limpiar(){
    document.getElementById('input-user').value = "";
    document.getElementById('input-password').value = "";
}
