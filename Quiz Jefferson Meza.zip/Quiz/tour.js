const panorama = new PANOLENS.ImagePanorama("snow360.jpg"); //Cargar de imagen 360
const viewer = new PANOLENS.Viewer({ //Crear vista de imagen
  container: document.querySelector("#panorama-container"),
  autoHideInfospot: false, //Los spots de información no desaparecen al mover la vista
  output: "console"
});
viewer.add(panorama); //agregar el panorama a la vista

const infoOverlay = document.createElement("div"); //agregar la creación de un div para el contenido de los spots
infoOverlay.id = "info-overlay";
infoOverlay.innerHTML = `
  <div id="info-content"></div>
  <button id="close-info">Cerrar</button>
`; //Botón para cerrar spot
document.body.appendChild(infoOverlay); //Traer al frente del body y mostrar encima

const infoContent = document.getElementById("info-content"); //Funcionalidad del botón cerrar
document.getElementById("close-info").addEventListener("click", () => {
  infoOverlay.style.display = "none";
  infoContent.innerHTML = "";
});

const infospots = [ //Configuración de spots
    {
      type: "text", //Tipo de spot
      text: "Ústí nad Labem es una encantadora ciudad situada al norte de la República Checa, a orillas del río Elba y rodeada por el impresionante paisaje del área protegida de las Montañas de Bohemia Central. Conocida por su mezcla única de historia industrial, belleza natural y arquitectura moderna, Ústí ofrece a los visitantes una experiencia completa: desde castillos medievales como el majestuoso Střekov, hasta vistas panorámicas desde el mirador de Větruše o paseos relajantes por el río. Además, su cercanía a formaciones rocosas y rutas de senderismo la convierte en un destino ideal tanto para los amantes de la cultura como de la naturaleza.", //Contenido de spot
      position: new THREE.Vector3(1900, -800, -5000) //Coordenadas de spot
    },
    {
      type: "pdf",
      url: "chequia.pdf",
      position: new THREE.Vector3(5500, -1100, -4000)
    },
    {
      type: "text",
      text: "El río Elba, uno de los más importantes de Europa Central, atraviesa la ciudad de Ústí nad Labem y le otorga gran parte de su encanto y vitalidad. A lo largo de sus orillas se pueden encontrar miradores naturales, senderos para caminar o andar en bicicleta, y puntos panorámicos desde donde se aprecia la armonía entre la ciudad y el paisaje montañoso circundante. Históricamente, el Elba fue una vía crucial para el comercio y el desarrollo industrial de la región, y hoy en día sigue siendo un símbolo de conexión, vida y belleza natural, reflejando en sus aguas la historia y el espíritu de Ústí nad Labem.",
      position: new THREE.Vector3(6000, -3100, -1000)
    },
    {
      type: "image",
      url: "iglesia.jpg",
      position: new THREE.Vector3(6500, 0, 2000)
    },
      {
      type: "video",
      url: "https://www.youtube.com/embed/IPCfeL3c1uo",
      position: new THREE.Vector3(3700, -600, 3000)
    },
    {
      type: "image",
      url: "vista.png",
      position: new THREE.Vector3(-3700, 1500, 3000)
    },
    {
      type: "text",
      text: "La estación de tren Ústí nad Labem – Ústí nad Labem hlavní nádraží, conocida también como U Nadraží, es un punto neurálgico para quienes llegan o parten de la ciudad. Con conexiones nacionales e internacionales, permite viajar cómodamente hacia ciudades como Praga, Dresde o Berlín, facilitando el acceso a Ústí nad Labem tanto para turistas como para viajeros de negocios. Su ubicación estratégica cerca del centro urbano hace que desde la estación sea fácil llegar a pie a muchos de los principales atractivos de la ciudad, incluyendo el puente Mariánský, el río Elba y varias zonas comerciales y de ocio. Además, la estación ofrece servicios modernos, tiendas y cafeterías, haciendo la llegada y salida de la ciudad una experiencia cómoda y agradable.",
      position: new THREE.Vector3(7000, -1000, 2000)
    },
    {
      type: "mixed",
      text: "El Zoológico de Ústí nad Labem es un destino ideal para toda la familia y uno de los espacios naturales más atractivos de la ciudad. Con una extensión de aproximadamente 26 hectáreas, alberga más de 1.500 animales de unas 240 especies diferentes, incluyendo leones, osos, primates y aves exóticas. Además de sus exhibiciones, el zoológico ofrece actividades interactivas, como demostraciones de alimentación, senderos educativos y áreas de juego para niños. Ubicado en un entorno pintoresco cerca de las colinas circundantes, permite combinar el contacto con la fauna con agradables paseos al aire libre y ofrece vistas panorámicas de la ciudad y el valle del río Elba.",
      url: "zoo.jpg",
      position: new THREE.Vector3(-9000, 1500, 10)
    },
    {
      type: "mixed",
      text: "El puente Mariánský es uno de los símbolos más modernos y representativos de Ústí nad Labem. Inaugurado en 1998, este elegante puente atirantado cruza el río Elba con una estructura ligera y futurista que contrasta de forma armoniosa con el entorno natural. Su diseño innovador le valió reconocimiento internacional, siendo considerado una de las obras de ingeniería más bellas de la década de 1990. Desde su pasarela peatonal se pueden disfrutar magníficas vistas del río, las colinas cercanas y la silueta urbana de la ciudad, especialmente al atardecer.",
      url: "puente.jpg",
      position: new THREE.Vector3(-4000, -1000, -3500)
    },
    {
      type: "mixed",
      text: "Dominando el paisaje desde lo alto de una roca sobre el Elba, el castillo Střekov es una de las joyas históricas más impresionantes de la región. Construido en el siglo XIII, este castillo gótico no solo protegía la ruta comercial del río, sino que también inspiró a artistas y escritores como Richard Wagner y Goethe por su atmósfera romántica y sus vistas espectaculares. Hoy, sus ruinas bien conservadas ofrecen un viaje al pasado, con senderos panorámicos, exposiciones y un restaurante con una de las mejores vistas de Ústí nad Labem y su valle fluvial.",
      url: "strekov.jpg",
      position: new THREE.Vector3(-500, 350, -4500)
    }
  ];

  infospots.forEach((spot) => { //Crear íconos para hacer click en el panorama
    const infospot = new PANOLENS.Infospot(350, PANOLENS.DataImage.Info); //Apariencia del spot
    infospot.position.copy(spot.position);
    panorama.add(infospot);

    infospot.addEventListener("click", () => { //Crear tipos de spots según su contenido, uso de iframes para pdf y video embed
      if (spot.type === "text") {
        infoContent.innerHTML = `<p>${spot.text}</p>`;
      } else if (spot.type === "image") {
        infoContent.innerHTML = `<img src="${spot.url}" style="max-width:100%;">`;
      } else if (spot.type === "video") {
        infoContent.innerHTML = `
          <iframe width="1280" height="720"
            src="${spot.url}"
            frameborder="0" allowfullscreen></iframe>`;
      } else if (spot.type === "pdf") {
        infoContent.innerHTML = `
          <iframe src="${spot.url}" width="800px" height="1000px"
            style="border:none;"></iframe>`;
      } else if (spot.type === "mixed") {
        infoContent.innerHTML = `
          <div style="display:flex; flex-direction:column; align-items:center;">
            <p>${spot.text}</p>
            <img src="${spot.url}" style="max-width:100%; margin-top:10px;">
          </div>`;
      }

      infoOverlay.style.display = "flex";
    });
  });